<?php

use CodeIgniter\Boot;
use Config\Paths;

$minPhpVersion = '8.2';
if (version_compare(PHP_VERSION, $minPhpVersion, '<')) {
    $message = sprintf(
        'Your PHP version must be %s or higher to run CodeIgniter. Current version: %s',
        $minPhpVersion,
        PHP_VERSION
    );

    header('HTTP/1.1 503 Service Unavailable.', true, 503);
    echo $message;

    exit(1);
}

define('FCPATH', __DIR__ . DIRECTORY_SEPARATOR);

if (getcwd() . DIRECTORY_SEPARATOR !== FCPATH) {
    chdir(FCPATH);
}

// Coba beberapa lokasi umum CI4 di shared hosting.
$candidateCi4Roots = [
    dirname(__DIR__) . '/ci4',
    dirname(__DIR__) . '/ci4',
];

$pathsFile = null;

foreach ($candidateCi4Roots as $root) {
    $candidate = $root . '/app/Config/Paths.php';
    if (is_file($candidate)) {
        $pathsFile = $candidate;
        break;
    }
}

if ($pathsFile === null) {
    header('HTTP/1.1 503 Service Unavailable.', true, 503);
    echo "Bootstrap CI4 gagal: Paths.php tidak ditemukan.\\n";
    echo "Lokasi yang dicek:\\n- " . implode("\\n- ", $candidateCi4Roots);
    exit(1);
}

require $pathsFile;

$paths = new Paths();

require $paths->systemDirectory . '/Boot.php';

exit(Boot::bootWeb($paths));
